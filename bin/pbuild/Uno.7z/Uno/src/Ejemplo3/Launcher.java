package Ejemplo3;

import java.io.File;

public class Launcher {
	public void lanzarSumador(Integer n1, Integer n2, String fichResultado) {
		String clase = "E:\\DAM2\\Programacion de servicios y procesos\\Eclipse\\Uno\\src\\Ejemplo3\\Sumador.java";
		ProcessBuilder pb;

		try {
			pb = new ProcessBuilder("java", clase, n1.toString(), n2.toString());
			pb.redirectError(new File("Errores.txt"));
			pb.redirectOutput(new File(fichResultado));
			pb.start();

		} catch (Exception e) {
			e.printStackTrace();

		}
	}

	public static void main(String[] args) {
		Launcher l = new Launcher();
		l.lanzarSumador(1, 10, "Suma.txt");
		l.lanzarSumador(11, 20, "Suma.txt");
		System.out.println("Se ha lanzado a Chonky");

	}
}